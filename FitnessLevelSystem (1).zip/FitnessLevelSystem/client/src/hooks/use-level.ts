import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { calculateXpForLevel, getRankForLevel, getRankProgress } from "@/lib/utils/rank-utils";
import type { User } from "@/lib/types";

export function useLevel() {
  const [prevLevel, setPrevLevel] = useState(1);
  const [xpRequired, setXpRequired] = useState(1000);
  const [nextRank, setNextRank] = useState("E");
  const [levelsToNextRank, setLevelsToNextRank] = useState(0);
  const [rankProgress, setRankProgress] = useState(0);
  
  // Fetch user data
  const { data: userData, isLoading } = useQuery<User>({
    queryKey: ["/api/users/1"],
  });
  
  // Default user data (for development/testing)
  const defaultUser = {
    id: 1,
    displayName: "Max Steel",
    username: "max_steel",
    level: 28,
    xp: 7545,
    rank: "D",
    points: 1250,
    email: "max@example.com"
  };
  
  // Use fetched user data or default
  const user = userData || defaultUser;
  
  // Update level-related state when user data changes
  useEffect(() => {
    if (user) {
      // Store previous level to detect level ups
      setPrevLevel(user.level);
      
      // Calculate XP required for next level
      const requiredXp = calculateXpForLevel(user.level + 1);
      setXpRequired(requiredXp);
      
      // Determine next rank and levels needed to reach it
      const currentRank = user.rank;
      const nextRankLetter = getNextRank(currentRank);
      setNextRank(nextRankLetter);
      
      // Calculate levels needed to reach next rank
      const levelsNeeded = calculateLevelsToNextRank(user.level, nextRankLetter);
      setLevelsToNextRank(levelsNeeded);
      
      // Calculate rank progress (0-100%)
      const progress = getRankProgress(user.level);
      setRankProgress(progress);
    }
  }, [user]);
  
  // Helper function to get the next rank
  function getNextRank(currentRank: string): string {
    const ranks = ["E", "D", "C", "B", "A", "S"];
    const currentIndex = ranks.indexOf(currentRank);
    
    if (currentIndex === -1 || currentIndex === ranks.length - 1) {
      return currentRank; // Return current rank if it's already the highest or invalid
    }
    
    return ranks[currentIndex + 1];
  }
  
  // Helper function to calculate levels needed for next rank
  function calculateLevelsToNextRank(currentLevel: number, nextRank: string): number {
    // Determine the minimum level for the next rank
    let minLevelForNextRank = 1;
    
    switch (nextRank) {
      case "D": minLevelForNextRank = 11; break;
      case "C": minLevelForNextRank = 31; break;
      case "B": minLevelForNextRank = 51; break;
      case "A": minLevelForNextRank = 71; break;
      case "S": minLevelForNextRank = 91; break;
      default: minLevelForNextRank = 1;
    }
    
    return Math.max(0, minLevelForNextRank - currentLevel);
  }
  
  // Check if user has leveled up
  function checkLevelUp(): boolean {
    if (!userData) return false;
    
    const hasLeveledUp = userData.level > prevLevel;
    if (hasLeveledUp) {
      setPrevLevel(userData.level);
    }
    
    return hasLeveledUp;
  }

  return {
    user,
    level: user.level,
    xp: user.xp,
    xpRequired,
    nextRank,
    levelsToNextRank,
    rankProgress,
    isLoading,
    checkLevelUp
  };
}
