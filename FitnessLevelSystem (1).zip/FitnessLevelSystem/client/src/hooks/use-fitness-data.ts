import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { calculateWeeklyXpGoal } from "@/lib/utils/fitness-utils";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { FitnessData } from "@/lib/types";

export function useFitnessData() {
  const [todayStats, setTodayStats] = useState({
    steps: 0,
    calories: 0,
    heartRate: 0,
    activeMinutes: 0,
  });
  
  const [weeklyXp, setWeeklyXp] = useState(0);
  const [weeklyXpGoal, setWeeklyXpGoal] = useState(21000);
  
  // Fetch today's fitness data
  const { data: fitnessData, isLoading, refetch } = useQuery<FitnessData>({
    queryKey: ["/api/users/1/fitness"],
  });
  
  // Fetch weekly fitness data
  const { data: weeklyData } = useQuery<FitnessData[]>({
    queryKey: ["/api/users/1/fitness/range"],
  });
  
  // Fetch user
  const { data: user } = useQuery({
    queryKey: ["/api/users/1"],
  });
  
  // Update today's stats when fitness data changes
  useEffect(() => {
    if (fitnessData) {
      setTodayStats({
        steps: fitnessData.steps || 0,
        calories: fitnessData.calories || 0,
        heartRate: fitnessData.avgHeartRate || 68,
        activeMinutes: fitnessData.activeMins || 0,
      });
    }
  }, [fitnessData]);
  
  // Calculate weekly XP when weekly data changes
  useEffect(() => {
    if (weeklyData) {
      // Sum up steps, calories, and active minutes for the week
      const totalSteps = weeklyData.reduce((sum, day) => sum + (day.steps || 0), 0);
      const totalCalories = weeklyData.reduce((sum, day) => sum + (day.calories || 0), 0);
      const totalActiveMinutes = weeklyData.reduce((sum, day) => sum + (day.activeMins || 0), 0);
      
      // Convert to XP (simplified formula for demo)
      const stepsXp = Math.floor(totalSteps / 100);
      const caloriesXp = Math.floor(totalCalories / 10);
      const activeMinutesXp = totalActiveMinutes * 5;
      
      const totalXp = stepsXp + caloriesXp + activeMinutesXp;
      setWeeklyXp(totalXp);
    }
  }, [weeklyData]);
  
  // Update weekly XP goal based on user level
  useEffect(() => {
    if (user) {
      const newGoal = calculateWeeklyXpGoal(user.level);
      setWeeklyXpGoal(newGoal);
    }
  }, [user]);
  
  // Function to refresh fitness data
  const refetchFitnessData = async () => {
    await refetch();
    queryClient.invalidateQueries({ queryKey: ["/api/users/1/fitness/range"] });
  };
  
  // Simulate syncing with external device
  const syncDevice = async (deviceId: string) => {
    try {
      await apiRequest("POST", "/api/fitbit/sync", {
        userId: 1, // Using a default ID for demo
        deviceId
      });
      await refetchFitnessData();
      return true;
    } catch (error) {
      console.error("Failed to sync device:", error);
      return false;
    }
  };

  return {
    todayStats,
    weeklyXp,
    weeklyXpGoal,
    isLoading,
    refetchFitnessData,
    syncDevice
  };
}
