import React, { useState, useEffect } from "react";
import { Header } from "@/components/layout/Header";
import { MobileNavigation } from "@/components/layout/MobileNavigation";
import { WelcomeSection } from "@/components/dashboard/WelcomeSection";
import { HunterStatus } from "@/components/dashboard/HunterStatus";
import { TodayStats } from "@/components/dashboard/TodayStats";
import { WeeklyActivity } from "@/components/dashboard/WeeklyActivity";
import { QuestsSection } from "@/components/quests/QuestsSection";
import { AchievementsSection } from "@/components/achievements/AchievementsSection";
import { RankingSystem } from "@/components/rank/RankingSystem";
import { ConnectedDevices } from "@/components/devices/ConnectedDevices";
import { RewardsStore } from "@/components/rewards/RewardsStore";
import { LevelUpModal } from "@/components/modals/LevelUpModal";
import { useLevel } from "@/hooks/use-level";
import { useFitnessData } from "@/hooks/use-fitness-data";
import { queryClient } from "@/lib/queryClient";

export default function Dashboard() {
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [weeklyActivity, setWeeklyActivity] = useState<{ day: string; percentage: number; isToday: boolean }[]>([]);
  
  const { 
    user, 
    level, 
    xp, 
    xpRequired, 
    nextRank, 
    levelsToNextRank, 
    rankProgress,
    checkLevelUp 
  } = useLevel();
  
  const { 
    todayStats, 
    weeklyXp, 
    weeklyXpGoal,
    isLoading, 
    refetchFitnessData
  } = useFitnessData();
  
  useEffect(() => {
    // Initialize weekly activity data
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const today = new Date().getDay(); // 0 is Sunday, 1 is Monday, etc.
    const todayIndex = today === 0 ? 6 : today - 1; // Convert to 0-indexed day of week (Mon=0, Sun=6)
    
    const data = days.map((day, index) => {
      // For demo, generate random data for past days
      let percentage = 0;
      if (index < todayIndex) {
        percentage = Math.floor(Math.random() * 100);
      } else if (index === todayIndex) {
        // Today's percentage based on steps progress
        percentage = Math.min(100, Math.round((todayStats.steps / 10000) * 100));
      }
      
      return {
        day,
        percentage,
        isToday: index === todayIndex
      };
    });
    
    setWeeklyActivity(data);
  }, [todayStats.steps]);
  
  const handleSyncSuccess = () => {
    // Refetch fitness data
    refetchFitnessData();
    queryClient.invalidateQueries({ queryKey: ["/api/users/1"] });
    
    // Check if user leveled up
    const didLevelUp = checkLevelUp();
    if (didLevelUp) {
      setShowLevelUp(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        user={{ 
          displayName: user.displayName || "Hunter",
          avatar: undefined
        }} 
        notifications={2}
      />
      
      <main className="flex-grow container mx-auto px-4 py-6 pb-20 md:pb-6">
        <WelcomeSection 
          user={{ 
            displayName: user.displayName || "Hunter",
            rank: user.rank || "E"
          }}
          onSyncSuccess={handleSyncSuccess}
        />
        
        <section className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <HunterStatus 
              level={level}
              xp={xp}
              xpRequired={xpRequired}
              nextRank={nextRank}
              levelsToNextRank={levelsToNextRank}
            />
            
            <TodayStats 
              steps={todayStats.steps}
              calories={todayStats.calories}
              heartRate={todayStats.heartRate}
              activeMinutes={todayStats.activeMinutes}
            />
            
            <WeeklyActivity 
              data={weeklyActivity}
              weeklyXp={weeklyXp}
              weeklyXpGoal={weeklyXpGoal}
            />
          </div>
        </section>
        
        <QuestsSection compact />
        
        <AchievementsSection compact />
        
        <RankingSystem 
          currentLevel={level}
          currentRank={user.rank || "E"}
          rankProgress={rankProgress}
        />
        
        <ConnectedDevices />
        
        <RewardsStore compact />
      </main>
      
      <MobileNavigation />
      
      <LevelUpModal 
        isOpen={showLevelUp} 
        onClose={() => setShowLevelUp(false)}
        level={level}
        rewards={[
          { type: "points", value: "+200 Store Points" },
          { type: "quest", value: 'New Quest: "Endurance Master"' },
          { type: "feature", value: "Access to Advanced Workout Plans" }
        ]}
      />
    </div>
  );
}
