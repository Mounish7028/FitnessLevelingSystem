import React, { useState } from "react";
import { Header } from "@/components/layout/Header";
import { MobileNavigation } from "@/components/layout/MobileNavigation";
import { AchievementsSection } from "@/components/achievements/AchievementsSection";
import UserAchievements from "@/components/user-achievements";
import HolographicPanel from "@/components/ui/holographic-panel";
import SystemButton from "@/components/ui/system-button";
import { useLevel } from "@/hooks/use-level";

export default function Achievements() {
  const { user } = useLevel();
  const [viewMode, setViewMode] = useState<'list' | 'system'>('list');

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-black to-black/90">
      <Header 
        user={{ 
          displayName: user.displayName || "Hunter",
          avatar: undefined
        }} 
      />
      
      <main className="flex-grow container mx-auto px-4 py-6 pb-20 md:pb-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-[#0A84FF] mb-2">Achievements System</h1>
          <p className="text-muted-foreground">Unlock achievements by completing fitness goals and special challenges.</p>
        </div>
        
        <div className="mb-6 flex justify-end gap-4">
          <SystemButton 
            onClick={() => setViewMode('list')}
            variant={viewMode === 'list' ? 'default' : 'outline'}
          >
            CLASSIC VIEW
          </SystemButton>
          <SystemButton 
            onClick={() => setViewMode('system')}
            variant={viewMode === 'system' ? 'default' : 'outline'}
          >
            SYSTEM VIEW
          </SystemButton>
        </div>
        
        {viewMode === 'list' ? (
          <AchievementsSection />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="col-span-1 md:col-span-2">
              <HolographicPanel 
                title="SYSTEM NOTIFICATION" 
                variant="primary"
                scan={true}
                glowIntensity="high"
              >
                <div className="p-4 text-center">
                  <p className="text-xl mb-4">Welcome to the Solo Leveling Achievement System</p>
                  <p className="text-gray-300 mb-6">Complete fitness tasks to unlock new abilities and ranks. Rise from E-rank to S-rank as you level up!</p>
                </div>
              </HolographicPanel>
            </div>
            
            <div className="md:col-span-1">
              <UserAchievements userId={1} />
            </div>
            
            <div className="md:col-span-1">
              <HolographicPanel 
                title="HUNTER INFORMATION" 
                variant="default"
                scan={false}
              >
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-bold text-[#0A84FF] mb-2">Current Rank: {user.rank || 'E'}</h3>
                    <p>Your hunter rank determines the types of quests and dungeons you can access.</p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold text-[#0A84FF] mb-2">Next Title Available</h3>
                    <div className="p-3 bg-black/40 rounded border border-gray-800">
                      <p className="text-white font-semibold">Advanced Hunter (D-Rank)</p>
                      <p className="text-sm text-gray-400">Required: Complete 5 E-Rank quests and reach Level 5</p>
                    </div>
                  </div>
                </div>
              </HolographicPanel>
            </div>
          </div>
        )}
      </main>
      
      <MobileNavigation />
    </div>
  );
}
