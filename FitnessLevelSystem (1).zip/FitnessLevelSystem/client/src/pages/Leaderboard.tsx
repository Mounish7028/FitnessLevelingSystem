import React, { useState } from "react";
import { Header } from "@/components/layout/Header";
import { MobileNavigation } from "@/components/layout/MobileNavigation";
import HolographicPanel from "@/components/ui/holographic-panel";
import { useLevel } from "@/hooks/use-level";
import { useQuery } from "@tanstack/react-query";
import { Medal, Trophy, Award } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

export default function Leaderboard() {
  const { user } = useLevel();
  const [leaderboardType, setLeaderboardType] = useState<"steps" | "xp">("steps");

  const { data: leaderboard, isLoading } = useQuery({
    queryKey: ["/api/leaderboard"],
  });

  // Sort leaderboard by selected type
  const sortedLeaderboard = React.useMemo(() => {
    if (!leaderboard) return [];
    return [...leaderboard].sort((a, b) => {
      if (leaderboardType === "steps") {
        return b.steps - a.steps;
      } else {
        return b.xp - a.xp;
      }
    });
  }, [leaderboard, leaderboardType]);

  // Find user's rank in the leaderboard
  const userRank = React.useMemo(() => {
    if (!leaderboard) return null;
    const index = sortedLeaderboard.findIndex(entry => entry.id === 1); // Using default ID for demo
    return index >= 0 ? index + 1 : null;
  }, [sortedLeaderboard]);

  const getMedalIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-accent" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-300" />;
      case 3:
        return <Medal className="h-6 w-6 text-amber-700" />;
      default:
        return <span className="text-muted-foreground text-sm font-mono w-6 text-center">{rank}</span>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        user={{
          displayName: user.displayName || "Hunter",
          avatar: undefined
        }}
      />

      <main className="flex-grow container mx-auto px-4 py-6 pb-20 md:pb-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary glow-text">Leaderboard</h1>
          <p className="text-muted-foreground">
            Compare your progress with other hunters and climb to the top.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <HolographicPanel className="lg:col-span-3">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Global Rankings</h2>
              <Tabs 
                defaultValue="steps" 
                value={leaderboardType}
                onValueChange={(value) => setLeaderboardType(value as "steps" | "xp")}
              >
                <TabsList>
                  <TabsTrigger value="steps">Steps</TabsTrigger>
                  <TabsTrigger value="xp">Hunter XP</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {isLoading ? (
              <div className="space-y-2">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="flex items-center p-2">
                    <Skeleton className="h-6 w-6 rounded-full mr-4" />
                    <Skeleton className="h-4 w-32 mr-auto" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[80px]">Rank</TableHead>
                      <TableHead>Hunter</TableHead>
                      <TableHead>Rank</TableHead>
                      <TableHead className="text-right">
                        {leaderboardType === "steps" ? "Steps" : "XP"}
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedLeaderboard.slice(0, 20).map((entry, index) => (
                      <TableRow 
                        key={entry.id}
                        className={entry.id === 1 ? "bg-primary/10" : ""} // Highlight current user
                      >
                        <TableCell>
                          <div className="flex items-center justify-center">
                            {getMedalIcon(index + 1)}
                          </div>
                        </TableCell>
                        <TableCell className="font-bold">{entry.displayName}</TableCell>
                        <TableCell>
                          <span className={`${entry.rank === "S" ? "text-accent" : "text-secondary"}`}>
                            {entry.rank}-Rank
                          </span>
                        </TableCell>
                        <TableCell className="text-right font-mono">
                          {leaderboardType === "steps" 
                            ? entry.steps.toLocaleString() 
                            : entry.xp.toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </HolographicPanel>

          <HolographicPanel>
            <h2 className="text-xl font-bold mb-4">Your Status</h2>
            
            <div className="flex items-center justify-center mb-6">
              <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center glow mb-4">
                <Award className="h-12 w-12 text-secondary" />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-sm text-muted-foreground">Global Rank</div>
                <div className="text-3xl font-bold text-secondary glow-text">
                  {userRank !== null ? `#${userRank}` : "-"}
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-sm text-muted-foreground">Hunter Level</div>
                <div className="text-2xl font-bold">{user.level}</div>
              </div>
              
              <div className="text-center">
                <div className="text-sm text-muted-foreground">Total Steps</div>
                <div className="text-xl font-mono">
                  {sortedLeaderboard.find(entry => entry.id === 1)?.steps.toLocaleString() || "-"}
                </div>
              </div>
            </div>
          </HolographicPanel>
        </div>

        <HolographicPanel>
          <h2 className="text-xl font-bold mb-4">Hunter Ranks: The Road to Greatness</h2>
          <p className="text-muted-foreground mb-6">
            In the world of hunters, power is measured by rank. Each rank represents not just your abilities,
            but your dedication to fitness and self-improvement.
          </p>
          
          <div className="space-y-4">
            <div className="flex items-center p-2 bg-muted/20 rounded-lg">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold">E</span>
              </div>
              <div>
                <h3 className="font-bold">E-Rank Hunter</h3>
                <p className="text-sm text-muted-foreground">The beginning of your journey (Levels 1-10)</p>
              </div>
            </div>
            
            <div className="flex items-center p-2 bg-muted/20 rounded-lg">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold">D</span>
              </div>
              <div>
                <h3 className="font-bold">D-Rank Hunter</h3>
                <p className="text-sm text-muted-foreground">Building strength and endurance (Levels 11-30)</p>
              </div>
            </div>
            
            <div className="flex items-center p-2 bg-muted/20 rounded-lg">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold">C</span>
              </div>
              <div>
                <h3 className="font-bold">C-Rank Hunter</h3>
                <p className="text-sm text-muted-foreground">A recognized force in fitness (Levels 31-50)</p>
              </div>
            </div>
            
            <div className="flex items-center p-2 bg-muted/20 rounded-lg">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold">B</span>
              </div>
              <div>
                <h3 className="font-bold">B-Rank Hunter</h3>
                <p className="text-sm text-muted-foreground">Elite level of fitness (Levels 51-70)</p>
              </div>
            </div>
            
            <div className="flex items-center p-2 bg-muted/20 rounded-lg">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold">A</span>
              </div>
              <div>
                <h3 className="font-bold">A-Rank Hunter</h3>
                <p className="text-sm text-muted-foreground">Masters of physical prowess (Levels 71-90)</p>
              </div>
            </div>
            
            <div className="flex items-center p-2 bg-muted/20 rounded-lg">
              <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center mr-4">
                <span className="font-bold text-accent">S</span>
              </div>
              <div>
                <h3 className="font-bold text-accent">S-Rank Hunter</h3>
                <p className="text-sm text-muted-foreground">Legendary status, beyond human limits (Levels 91+)</p>
              </div>
            </div>
          </div>
        </HolographicPanel>
      </main>

      <MobileNavigation />
    </div>
  );
}
