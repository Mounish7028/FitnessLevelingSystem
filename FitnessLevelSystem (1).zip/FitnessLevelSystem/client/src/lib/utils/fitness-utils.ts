import { FITNESS_GOALS, WEEKLY_XP_GOALS } from "../constants";
import type { FitnessData } from "../types";

/**
 * Calculate calories burned based on steps and user weight
 * @param steps Number of steps taken
 * @param weightKg User's weight in kg (default: 70)
 * @returns Estimated calories burned
 */
export function calculateCaloriesFromSteps(steps: number, weightKg: number = 70): number {
  // Approximate calories burned per step based on weight
  const caloriesPerStep = 0.04 * (weightKg / 70);
  return Math.round(steps * caloriesPerStep);
}

/**
 * Calculate distance traveled based on steps and stride length
 * @param steps Number of steps taken
 * @param strideM Stride length in meters (default: 0.762m which is ~30 inches)
 * @returns Distance in meters
 */
export function calculateDistanceFromSteps(steps: number, strideM: number = 0.762): number {
  return Math.round(steps * strideM);
}

/**
 * Calculate average heart rate from fitness data
 * @param fitnessDataArray Array of fitness data points
 * @returns Average heart rate or undefined if no data
 */
export function calculateAverageHeartRate(fitnessDataArray: FitnessData[]): number | undefined {
  const heartRates = fitnessDataArray
    .filter(data => data.avgHeartRate !== undefined)
    .map(data => data.avgHeartRate as number);
  
  if (heartRates.length === 0) return undefined;
  
  const sum = heartRates.reduce((total, rate) => total + rate, 0);
  return Math.round(sum / heartRates.length);
}

/**
 * Calculate weekly XP goal based on user level
 * @param level The user's current level
 * @returns Weekly XP goal
 */
export function calculateWeeklyXpGoal(level: number): number {
  if (level < 11) return WEEKLY_XP_GOALS.beginner;
  if (level < 31) return WEEKLY_XP_GOALS.intermediate;
  if (level < 51) return WEEKLY_XP_GOALS.advanced;
  if (level < 71) return WEEKLY_XP_GOALS.elite;
  if (level < 91) return WEEKLY_XP_GOALS.master;
  return WEEKLY_XP_GOALS.legendary;
}

/**
 * Calculate XP earned from steps
 * @param steps Number of steps
 * @returns XP earned
 */
export function calculateXpFromSteps(steps: number): number {
  // Base formula: 1 XP per 100 steps
  return Math.floor(steps / 100);
}

/**
 * Calculate XP earned from calories burned
 * @param calories Number of calories burned
 * @returns XP earned
 */
export function calculateXpFromCalories(calories: number): number {
  // Base formula: 1 XP per 10 calories
  return Math.floor(calories / 10);
}

/**
 * Calculate XP earned from active minutes
 * @param activeMinutes Minutes of active time
 * @returns XP earned
 */
export function calculateXpFromActiveMinutes(activeMinutes: number): number {
  // Base formula: 5 XP per active minute
  return activeMinutes * 5;
}

/**
 * Calculate total XP earned from a fitness data point
 * @param fitnessData A single fitness data entry
 * @returns Total XP earned
 */
export function calculateTotalXpFromFitnessData(fitnessData: FitnessData): number {
  const stepsXp = calculateXpFromSteps(fitnessData.steps || 0);
  const caloriesXp = calculateXpFromCalories(fitnessData.calories || 0);
  const activeMinutesXp = calculateXpFromActiveMinutes(fitnessData.activeMins || 0);
  
  return stepsXp + caloriesXp + activeMinutesXp;
}

/**
 * Format steps with commas for thousands
 * @param steps Number of steps
 * @returns Formatted steps string
 */
export function formatSteps(steps: number): string {
  return steps.toLocaleString();
}

/**
 * Calculate percentage of goal achieved
 * @param current Current value
 * @param goal Goal value
 * @returns Percentage (0-100) of goal achieved
 */
export function calculateGoalPercentage(current: number, goal: number): number {
  if (goal <= 0) return 0;
  return Math.min(100, Math.round((current / goal) * 100));
}

/**
 * Check if fitness goals are met
 * @param fitnessData Current fitness data
 * @returns Object with boolean flags for each goal
 */
export function checkFitnessGoals(fitnessData: FitnessData): Record<string, boolean> {
  return {
    stepsGoalMet: (fitnessData.steps || 0) >= FITNESS_GOALS.steps,
    caloriesGoalMet: (fitnessData.calories || 0) >= FITNESS_GOALS.calories,
    activeMinutesGoalMet: (fitnessData.activeMins || 0) >= FITNESS_GOALS.activeMinutes
  };
}

/**
 * Generate mock weekly activity data
 * @param currentDay Current day of week (0 = Sunday, 1 = Monday, etc.)
 * @param todaySteps Steps for the current day
 * @returns Array of weekly activity data
 */
export function generateWeeklyActivityData(currentDay: number, todaySteps: number): {
  day: string;
  percentage: number;
  isToday: boolean;
}[] {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const today = currentDay === 0 ? 6 : currentDay - 1; // Convert to 0-indexed day of week (Mon=0, Sun=6)
  
  return days.map((day, index) => {
    // Past days have random data, today uses actual steps, future days are empty
    let percentage = 0;
    if (index < today) {
      percentage = Math.floor(Math.random() * 100);
    } else if (index === today) {
      percentage = Math.min(100, Math.round((todaySteps / FITNESS_GOALS.steps) * 100));
    }
    
    return {
      day,
      percentage,
      isToday: index === today
    };
  });
}
