import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Function to get title for a rank
export function getRankTitle(rank: string): string {
  switch (rank) {
    case 'S':
      return 'Monarch';
    case 'A':
      return 'National Level Hunter';
    case 'B':
      return 'Master Hunter';
    case 'C':
      return 'Elite Hunter';
    case 'D':
      return 'Advanced Hunter';
    case 'E':
    default:
      return 'Hunter';
  }
}

// Format number with commas
export function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Format date to readable string
export function formatDate(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric' 
  });
}

// Calculate XP needed for next level
export function getXpForNextLevel(currentLevel: number): number {
  return Math.floor(100 * Math.pow(1.5, currentLevel - 1));
}

// Get color for rank
export function getRankColor(rank: string): string {
  switch (rank) {
    case 'S':
      return '#FFD700'; // Gold
    case 'A':
      return '#FF5733'; // Red-Orange
    case 'B':
      return '#9933FF'; // Purple
    case 'C':
      return '#33A1FF'; // Blue
    case 'D':
      return '#33FF57'; // Green
    case 'E':
    default:
      return '#AAAAAA'; // Gray
  }
}
