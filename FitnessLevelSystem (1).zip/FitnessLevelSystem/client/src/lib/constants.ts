// Ranks
export const RANKS = {
  E: { 
    name: "E-Rank Hunter", 
    title: "Novice", 
    minLevel: 1, 
    maxLevel: 10,
    color: "#ACACAC"
  },
  D: { 
    name: "D-Rank Hunter", 
    title: "Skilled", 
    minLevel: 11, 
    maxLevel: 30,
    color: "#3498DB" 
  },
  C: { 
    name: "C-Rank Hunter", 
    title: "Expert", 
    minLevel: 31, 
    maxLevel: 50,
    color: "#52BE80" 
  },
  B: { 
    name: "B-Rank Hunter", 
    title: "Seasoned", 
    minLevel: 51, 
    maxLevel: 70,
    color: "#F39C12" 
  },
  A: { 
    name: "A-Rank Hunter", 
    title: "Veteran", 
    minLevel: 71, 
    maxLevel: 90,
    color: "#E74C3C" 
  },
  S: { 
    name: "S-Rank Hunter", 
    title: "Elite", 
    minLevel: 91, 
    maxLevel: 120,
    color: "#9B59B6" 
  },
  NATIONAL: { 
    name: "National Level Hunter", 
    title: "Champion", 
    minLevel: 121, 
    maxLevel: Infinity,
    color: "#F1C40F" 
  }
};

// XP required for each level (formula: base * level^2)
export const BASE_XP_REQUIREMENT = 100;

// Default fitness goals
export const FITNESS_GOALS = {
  steps: 10000,
  calories: 2000,
  activeMinutes: 60,
  workouts: 5
};

// Weekly XP goals by level range
export const WEEKLY_XP_GOALS = {
  beginner: 10000,    // Levels 1-10
  intermediate: 21000, // Levels 11-30
  advanced: 35000,     // Levels 31-50
  elite: 50000,        // Levels 51-70
  master: 75000,       // Levels 71-90
  legendary: 100000    // Levels 91+
};

// Achievement Types
export const ACHIEVEMENT_TYPES = {
  STEPS: "steps",
  CALORIES: "calories",
  WORKOUTS: "workouts",
  STREAK: "streak",
  MILESTONE: "milestone"
};

// Quest Types
export const QUEST_TYPES = {
  DAILY: "daily",
  WEEKLY: "weekly",
  MONTHLY: "monthly",
  SPECIAL: "special"
};

// Device Types
export const DEVICE_TYPES = {
  SMART_WATCH: "smartwatch",
  FITNESS_TRACKER: "fitnesstracker",
  SMART_PHONE: "smartphone"
};

// Icons for different activities
export const ACTIVITY_ICONS = {
  walking: "footsteps-outline",
  running: "run-outline",
  cycling: "bicycle-outline",
  swimming: "water-outline",
  workout: "barbell-outline",
  sleep: "bed-outline",
  heart: "heart-outline",
  calories: "flame-outline",
  time: "time-outline",
  achievement: "trophy-outline"
};

// Points awarded for different activities
export const POINTS_REWARDS = {
  stepsMilestone: 50,  // Every 10,000 steps
  caloriesMilestone: 75, // Every 1,000 calories burned
  workoutComplete: 100, // Per workout
  questComplete: {
    daily: 50,
    weekly: 250,
    monthly: 1000,
    special: 500
  },
  achievementUnlock: 200
};

// Level up rewards by level
export const LEVEL_UP_REWARDS = [
  { level: 5, rewards: [{ type: "points", value: "+100 Store Points" }, { type: "feature", value: "Workout Tracking" }] },
  { level: 10, rewards: [{ type: "points", value: "+150 Store Points" }, { type: "feature", value: "Daily Quests" }] },
  { level: 15, rewards: [{ type: "points", value: "+200 Store Points" }, { type: "quest", value: "New Quest: Cardio Master" }] },
  { level: 20, rewards: [{ type: "points", value: "+250 Store Points" }, { type: "feature", value: "Weekly Challenges" }] },
  { level: 25, rewards: [{ type: "points", value: "+300 Store Points" }, { type: "quest", value: "New Quest: Strength Builder" }] },
  { level: 30, rewards: [{ type: "points", value: "+350 Store Points" }, { type: "feature", value: "Rank Up: D to C" }] },
  // Add more level rewards as needed
];

// Default level up rewards if specific level not found
export const DEFAULT_LEVEL_UP_REWARDS = [
  { type: "points", value: "+200 Store Points" },
  { type: "quest", value: "New Quest: Endurance Master" },
  { type: "feature", value: "Access to Advanced Workout Plans" }
];

// Dungeon types
export const DUNGEON_TYPES = {
  STANDARD: "standard",      // Regular dungeons
  BOSS: "boss",              // Boss dungeons (tougher)
  RED_GATE: "red_gate",      // Special high difficulty gates (like Red Gates in Solo Leveling)
  DOUBLE_GATE: "double_gate" // Double dungeons (longer duration)
};

// Dungeon difficulties based on rank
export const DUNGEON_DIFFICULTY = {
  E: { baseXP: 300, basePoints: 100, stepsMultiplier: 0.8 },
  D: { baseXP: 600, basePoints: 200, stepsMultiplier: 1 },
  C: { baseXP: 1200, basePoints: 400, stepsMultiplier: 1.2 },
  B: { baseXP: 2400, basePoints: 800, stepsMultiplier: 1.5 },
  A: { baseXP: 4800, basePoints: 1600, stepsMultiplier: 2 },
  S: { baseXP: 9600, basePoints: 3200, stepsMultiplier: 3 }
};

// Hunter Association events/competitions
export const HUNTER_EVENTS = {
  BEGINNER_TRAINING: { name: "Novice Training Camp", minRank: "E", maxRank: "D", duration: 7 }, // Days
  REGIONAL_TOURNAMENT: { name: "Regional Hunter Tournament", minRank: "C", maxRank: "B", duration: 14 },
  NATIONAL_COMPETITION: { name: "National Hunter Competition", minRank: "A", maxRank: "S", duration: 30 },
  WORLD_CHAMPIONSHIP: { name: "World Hunter Championship", minRank: "S", maxRank: "NATIONAL", duration: 60 }
};
