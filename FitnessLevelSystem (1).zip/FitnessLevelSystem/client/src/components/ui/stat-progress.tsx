import React from "react";
import { cn } from "@/lib/utils";

interface StatProgressProps {
  value: number;
  max: number;
  showText?: boolean;
  className?: string;
  formatValue?: (value: number) => string;
  formatMax?: (max: number) => string;
  achievement?: boolean;
}

export function StatProgress({ 
  value,
  max,
  showText = true,
  className = "",
  formatValue = (v) => v.toString(),
  formatMax = (m) => m.toString(),
  achievement = false
}: StatProgressProps) {
  const percent = Math.min(100, Math.max(0, (value / max) * 100));
  
  return (
    <div className={className}>
      {showText && (
        <div className="flex justify-between mb-1">
          <span className="text-sm text-muted-foreground">Progress</span>
          <span className={`text-sm ${achievement ? "text-accent" : "text-secondary"}`}>
            {formatValue(value)} / {formatMax(max)}
          </span>
        </div>
      )}
      <div className="w-full bg-muted rounded-full h-2">
        <div 
          className={`h-2 rounded-full ${achievement ? "bg-accent" : "stat-progress"}`} 
          style={{ width: `${percent}%` }}
        ></div>
      </div>
    </div>
  );
}
