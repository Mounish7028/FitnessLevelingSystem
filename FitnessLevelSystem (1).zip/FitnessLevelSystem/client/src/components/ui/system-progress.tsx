import React from "react";
import { cn } from "@/lib/utils";

interface SystemProgressProps {
  value: number;
  max: number;
  className?: string;
  barClassName?: string;
  showLabel?: boolean;
  label?: string;
  size?: "sm" | "md" | "lg";
  color?: "blue" | "green" | "red" | "yellow";
}

const SystemProgress = ({
  value,
  max,
  className,
  barClassName,
  showLabel = false,
  label,
  size = "md",
  color = "blue",
}: SystemProgressProps) => {
  const percentage = Math.min(Math.max(0, (value / max) * 100), 100);
  
  const sizeClasses = {
    sm: "h-2",
    md: "h-3",
    lg: "h-4",
  };
  
  const colorClasses = {
    blue: "from-[#0A84FF] to-[#00F2FE]",
    green: "from-[#27c46c] to-[#05db95]",
    red: "from-[#ff4747] to-[#ff7676]",
    yellow: "from-[#ffd700] to-[#ffaa00]",
  };
  
  const displayLabel = label || `${Math.round(percentage)}%`;

  return (
    <div className={cn("w-full", className)}>
      <div className="relative w-full overflow-hidden rounded-sm bg-black/70 border border-[#0A84FF]/50">
        <div
          className={cn(
            "relative rounded-sm bg-gradient-to-r transition-all duration-300",
            sizeClasses[size],
            colorClasses[color],
            barClassName
          )}
          style={{ width: `${percentage}%` }}
        >
          {/* Animated glow effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse-slow opacity-50" />
        </div>
      </div>
      
      {showLabel && (
        <div className="mt-1 flex justify-between text-xs">
          <span className="text-[#0A84FF]">{displayLabel}</span>
          <span className="text-gray-400">{value} / {max}</span>
        </div>
      )}
    </div>
  );
};

export default SystemProgress;