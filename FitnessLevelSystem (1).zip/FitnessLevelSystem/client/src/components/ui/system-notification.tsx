import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import SystemWindow from "./system-window";
import SystemButton from "./system-button";

interface SystemNotificationProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  showIcon?: boolean;
  actions?: {
    label: string;
    onClick: () => void;
  }[];
  onClose?: () => void;
}

const SystemNotification = ({
  title = "NOTIFICATION",
  children,
  className,
  showIcon = true,
  actions,
  onClose,
}: SystemNotificationProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Animate in
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);

    return () => clearTimeout(timer);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(() => {
      if (onClose) onClose();
    }, 300);
  };

  return (
    <div
      className={cn(
        "fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm transition-opacity duration-300",
        isVisible ? "opacity-100" : "opacity-0",
        className
      )}
    >
      <SystemWindow 
        title={title}
        className={cn(
          "max-w-md transition-all duration-300",
          isVisible ? "scale-100" : "scale-95"
        )}
        scanEffect
      >
        <div className="flex flex-col">
          {showIcon && (
            <div className="mb-4 flex justify-center">
              <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-[#0A84FF] text-[#0A84FF]">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="h-6 w-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"
                  />
                </svg>
              </div>
            </div>
          )}
          
          <div className="mb-6 text-center text-white">
            {children}
          </div>
          
          <div className={cn(
            "flex",
            actions && actions.length > 1 ? "justify-between space-x-4" : "justify-center"
          )}>
            {actions ? (
              actions.map((action, index) => (
                <SystemButton 
                  key={index} 
                  onClick={action.onClick}
                  className="flex-1"
                >
                  {action.label}
                </SystemButton>
              ))
            ) : (
              <SystemButton onClick={handleClose} className="min-w-[100px]">
                CONFIRM
              </SystemButton>
            )}
          </div>
        </div>
      </SystemWindow>
    </div>
  );
};

export default SystemNotification;