import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface SystemWindowProps {
  title?: string;
  className?: string;
  children: React.ReactNode;
  scanEffect?: boolean;
  glowEffect?: boolean;
}

const SystemWindow = ({
  title,
  className,
  children,
  scanEffect = false,
  glowEffect = true,
}: SystemWindowProps) => {
  const [scanLine, setScanLine] = useState(0);
  
  useEffect(() => {
    if (!scanEffect) return;
    
    const interval = setInterval(() => {
      setScanLine((prev) => {
        if (prev >= 100) return 0;
        return prev + 1;
      });
    }, 15);
    
    return () => clearInterval(interval);
  }, [scanEffect]);

  return (
    <div
      className={cn(
        "relative rounded border-2 border-[#0A84FF] bg-black/90 p-4 backdrop-blur-md",
        glowEffect && "shadow-[0_0_15px_rgba(10,132,255,0.5)]",
        className
      )}
    >
      {title && (
        <div className="absolute -top-4 left-4 bg-black px-2 text-xs font-bold uppercase tracking-wider text-[#0A84FF]">
          {title}
        </div>
      )}
      
      <div className="relative z-10">
        {children}
      </div>
      
      {scanEffect && (
        <div 
          className="absolute inset-0 z-0 overflow-hidden bg-gradient-to-b from-[#0A84FF]/10 to-transparent opacity-30 pointer-events-none"
          style={{ top: `${scanLine}%`, height: '15%' }}
        />
      )}
      
      {/* Corner accents */}
      <div className="absolute left-0 top-0 h-3 w-3 border-l-2 border-t-2 border-[#00F2FE]" />
      <div className="absolute right-0 top-0 h-3 w-3 border-r-2 border-t-2 border-[#00F2FE]" />
      <div className="absolute bottom-0 left-0 h-3 w-3 border-b-2 border-l-2 border-[#00F2FE]" />
      <div className="absolute bottom-0 right-0 h-3 w-3 border-b-2 border-r-2 border-[#00F2FE]" />
    </div>
  );
};

export default SystemWindow;