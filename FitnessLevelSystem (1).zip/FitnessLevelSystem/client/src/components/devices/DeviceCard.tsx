import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { Watch, ActivitySquare, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Device {
  id: number;
  name: string;
  deviceType: string;
  isConnected: boolean;
  lastSynced?: string;
}

interface DeviceCardProps {
  device: Device;
  onToggleConnection: () => void;
}

export function DeviceCard({ device, onToggleConnection }: DeviceCardProps) {
  const { toast } = useToast();
  
  const getDeviceIcon = (type: string) => {
    switch (type) {
      case "smartwatch":
        return <Watch className="h-10 w-10 text-secondary" />;
      default:
        return <ActivitySquare className="h-10 w-10 text-muted-foreground" />;
    }
  };
  
  const formatLastSynced = (dateString?: string) => {
    if (!dateString) return "Never";
    
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hours ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} days ago`;
  };
  
  const toggleConnection = async () => {
    try {
      await apiRequest("PUT", `/api/users/1/devices/${device.id}`, {
        isConnected: !device.isConnected,
        lastSynced: device.isConnected ? device.lastSynced : new Date().toISOString()
      });
      
      toast({
        title: device.isConnected ? "Device Disconnected" : "Device Connected",
        description: device.isConnected 
          ? "Your device has been disconnected." 
          : "Your device has been connected successfully.",
        variant: "default",
      });
      
      onToggleConnection();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update device connection. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <HolographicPanel 
      className={`flex items-center ${!device.isConnected ? "opacity-50" : ""}`}
    >
      <div className={`bg-${device.isConnected ? "primary" : "muted"} bg-opacity-20 p-4 rounded-lg mr-4`}>
        {getDeviceIcon(device.deviceType)}
      </div>
      
      <div>
        <h3 className="text-lg font-bold">{device.name}</h3>
        <p className="text-sm text-muted-foreground">
          Last synced: {formatLastSynced(device.lastSynced)}
        </p>
        <div className="flex items-center mt-2">
          <span 
            className={`w-2 h-2 ${device.isConnected ? "bg-green-500" : "bg-muted"} rounded-full mr-2`}
          ></span>
          <button 
            className={`text-xs ${device.isConnected ? "text-green-500" : "text-muted-foreground"}`}
            onClick={toggleConnection}
          >
            {device.isConnected ? "Connected" : "Disconnected"}
          </button>
        </div>
      </div>
    </HolographicPanel>
  );
}
