import React, { useState, useEffect } from 'react';
import SystemNotification from './ui/system-notification';
import { useAudio } from '@/hooks/use-audio';
import { useLocation } from 'wouter';

interface WelcomeNotificationProps {
  username: string;
  onClose?: () => void;
}

const WelcomeNotification = ({ username, onClose }: WelcomeNotificationProps) => {
  const [show, setShow] = useState(false);
  const { playNotificationSound, speakText } = useAudio();
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Delay showing the notification for a brief moment
    const timer = setTimeout(() => {
      setShow(true);
      playNotificationSound();
      speakText(`Welcome, ${username}. You are qualified to be a Player.`);
    }, 1000);

    return () => clearTimeout(timer);
  }, [playNotificationSound, speakText, username]);

  const handleAccept = () => {
    setShow(false);
    setTimeout(() => {
      if (onClose) onClose();
      setLocation('/');
    }, 300);
  };

  const handleDecline = () => {
    setShow(false);
    setTimeout(() => {
      if (onClose) onClose();
    }, 300);
  };

  if (!show) return null;

  return (
    <SystemNotification
      title="NOTIFICATION"
      actions={[
        { label: 'Yes', onClick: handleAccept },
        { label: 'No', onClick: handleDecline },
      ]}
    >
      <p className="mb-2 text-xl font-semibold text-[#0A84FF]">
        You are qualified to be a Player
      </p>
      <p className="mb-4">
        Only those who rank E or higher are allowed to proceed.
      </p>
      <p className="font-light text-gray-300">
        Will you accept?
      </p>
    </SystemNotification>
  );
};

export default WelcomeNotification;