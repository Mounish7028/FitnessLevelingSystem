import React from "react";
import { Link, useLocation } from "wouter";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Bell, Menu } from "lucide-react";

interface HeaderProps {
  user: {
    displayName: string;
    avatar?: string;
  };
  notifications?: number;
}

export function Header({ user, notifications = 0 }: HeaderProps) {
  const [location] = useLocation();
  
  const navItems = [
    { label: "Dashboard", path: "/" },
    { label: "Quests", path: "/quests" },
    { label: "Achievements", path: "/achievements" },
    { label: "Store", path: "/store" },
    { label: "Leaderboard", path: "/leaderboard" }
  ];

  return (
    <header className="holographic-panel sticky top-0 z-50 backdrop-blur-md">
      <div className="container mx-auto flex justify-between items-center p-4">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center glow">
            <span className="text-2xl font-bold text-white glow-text">S</span>
          </div>
          <h1 className="text-2xl font-bold text-white">
            <span className="text-secondary glow-text">LEVEL UP</span>{" "}
            <span className="text-white">FITNESS</span>
          </h1>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
              className={`
                transition-colors duration-300
                ${location === item.path 
                  ? "text-secondary" 
                  : "text-white hover:text-secondary"}
              `}
            >
              {item.label}
            </Link>
          ))}
        </div>
        
        <div className="flex items-center">
          <button className="relative p-2 text-white">
            <Bell className="h-6 w-6" />
            {notifications > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full"></span>
            )}
          </button>
          
          <div className="flex items-center ml-4 bg-opacity-30 bg-primary rounded-full p-1 glow">
            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center overflow-hidden">
              {user.avatar ? (
                <img src={user.avatar} alt={user.displayName} className="w-full h-full object-cover" />
              ) : (
                <span className="text-sm font-bold">{user.displayName.charAt(0)}</span>
              )}
            </div>
            <span className="hidden md:inline-block ml-2 mr-2 text-white font-semibold">
              {user.displayName}
            </span>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger className="ml-4 md:hidden">
              <Menu className="h-6 w-6 text-white" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {navItems.map((item) => (
                <DropdownMenuItem key={item.path} asChild>
                  <Link href={item.path}>{item.label}</Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
