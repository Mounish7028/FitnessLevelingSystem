import React from "react";
import { Link, useLocation } from "wouter";
import { Home, Trophy, Award, Gift, BarChart } from "lucide-react";

export function MobileNavigation() {
  const [location] = useLocation();
  
  const navItems = [
    { label: "Home", path: "/", icon: Home },
    { label: "Quests", path: "/quests", icon: Trophy },
    { label: "Achieve", path: "/achievements", icon: Award },
    { label: "Store", path: "/store", icon: Gift },
    { label: "Ranks", path: "/leaderboard", icon: BarChart }
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-background border-t border-border z-40">
      <div className="flex justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link 
              key={item.path} 
              href={item.path}
              className={`flex flex-col items-center ${
                isActive ? "text-secondary" : "text-white"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
