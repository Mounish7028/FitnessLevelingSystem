import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface WelcomeSectionProps {
  user: {
    displayName: string;
    rank: string;
  };
  onSyncSuccess?: () => void;
}

export function WelcomeSection({ user, onSyncSuccess }: WelcomeSectionProps) {
  const { toast } = useToast();
  const [syncing, setSyncing] = React.useState(false);
  
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };
  
  const handleSync = async () => {
    setSyncing(true);
    try {
      await apiRequest("POST", "/api/fitbit/sync", {
        userId: 1, // Using a default ID for demo
        deviceId: "apple-watch-123"
      });
      
      toast({
        title: "Device Synced",
        description: "Your fitness data has been updated successfully.",
        variant: "default",
      });
      
      if (onSyncSuccess) {
        onSyncSuccess();
      }
    } catch (error) {
      toast({
        title: "Sync Failed",
        description: "There was an issue syncing your device.",
        variant: "destructive",
      });
    } finally {
      setSyncing(false);
    }
  };

  return (
    <section className="mb-8">
      <HolographicPanel>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">
              {getGreeting()},{" "}
              <span className="text-secondary glow-text">{user.displayName}</span>
            </h2>
            <p className="text-muted-foreground mt-1">Ready to conquer today's challenges?</p>
          </div>
          
          <div className="flex items-center mt-4 md:mt-0">
            <Button 
              variant="outline" 
              className="glow mr-4 flex items-center gap-2 bg-primary/30 hover:bg-primary/50"
              onClick={handleSync}
              disabled={syncing}
            >
              <RefreshCw className={`h-4 w-4 ${syncing ? "animate-spin" : ""}`} />
              <span>{syncing ? "Syncing..." : "Sync Device"}</span>
            </Button>
            
            <div className="flex flex-col items-center">
              <span className="text-xs text-muted-foreground">Current Rank</span>
              <span className="text-lg font-bold text-accent glow-text">{user.rank}-RANK HUNTER</span>
            </div>
          </div>
        </div>
      </HolographicPanel>
    </section>
  );
}