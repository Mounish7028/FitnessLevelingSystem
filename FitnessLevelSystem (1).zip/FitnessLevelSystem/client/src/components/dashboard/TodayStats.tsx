import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { Footprints, Flame, Heart, Timer } from "lucide-react";

interface Stat {
  icon: React.ElementType;
  value: number;
  label: string;
  goal?: number;
  unit?: string;
}

interface TodayStatsProps {
  steps: number;
  calories: number;
  heartRate: number;
  activeMinutes: number;
  goalSteps?: number;
  goalCalories?: number;
  restingHeartRate?: number;
  goalActiveMinutes?: number;
}

export function TodayStats({
  steps,
  calories,
  heartRate,
  activeMinutes,
  goalSteps = 10000,
  goalCalories = 2000,
  restingHeartRate = 62,
  goalActiveMinutes = 60
}: TodayStatsProps) {
  const stats: Stat[] = [
    {
      icon: Footprints,
      value: steps,
      label: "Steps",
      goal: goalSteps
    },
    {
      icon: Flame,
      value: calories,
      label: "Calories",
      goal: goalCalories
    },
    {
      icon: Heart,
      value: heartRate,
      label: "Avg. BPM",
      unit: `Resting: ${restingHeartRate}`
    },
    {
      icon: Timer,
      value: activeMinutes,
      label: "Active (min)",
      goal: goalActiveMinutes
    }
  ];

  return (
    <HolographicPanel className="h-full">
      <h3 className="text-xl font-bold mb-4">Today's Stats</h3>
      
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="text-center">
              <div className="flex items-center justify-center">
                <Icon className="h-6 w-6 text-[#36D1DC] mr-2" />
                <span className="text-2xl font-bold text-white">
                  {stat.value.toLocaleString()}
                </span>
              </div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
              <div className="text-xs text-secondary">
                {stat.goal 
                  ? `Goal: ${stat.goal.toLocaleString()}`
                  : stat.unit}
              </div>
            </div>
          );
        })}
      </div>
    </HolographicPanel>
  );
}
