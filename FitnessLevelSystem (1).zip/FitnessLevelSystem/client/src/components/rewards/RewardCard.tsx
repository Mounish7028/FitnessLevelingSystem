import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";
import { Button } from "@/components/ui/button";

interface Reward {
  id: number;
  name: string;
  description: string;
  image: string;
  pointsCost: number;
  requiredRank?: string;
  isAvailable: boolean;
}

interface RewardCardProps {
  reward: Reward;
  userPoints: number;
  onRedeem: () => void;
}

export function RewardCard({ reward, userPoints, onRedeem }: RewardCardProps) {
  const canRedeem = reward.isAvailable && userPoints >= reward.pointsCost;
  const isRankLocked = reward.requiredRank === "S";
  
  const getImageUrl = (imageName: string) => {
    // Map image names to placeholder images for the demo
    switch (imageName) {
      case "protein_shake.jpg":
        return "https://images.unsplash.com/photo-1550345332-09e3ac987658?auto=format&fit=crop&w=600&q=80";
      case "fitness_apparel.jpg":
        return "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=600&q=80";
      case "water_bottle.jpg":
        return "https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&w=600&q=80";
      case "resistance_bands.jpg":
        return "https://images.unsplash.com/photo-1598447399662-a90d2c5cd05e?auto=format&fit=crop&w=600&q=80";
      case "creatine.jpg":
        return "https://images.unsplash.com/photo-1661607428647-2fa0b554e4fa?auto=format&fit=crop&w=600&q=80";
      case "training_shoes.jpg":
        return "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80";
      case "mystery_reward.jpg":
        return "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?auto=format&fit=crop&w=600&q=80";
      case "workout_plan.jpg":
        return "https://images.unsplash.com/photo-1465453869711-7e174808ace9?auto=format&fit=crop&w=600&q=80";
      case "hunter_badge.jpg":
        return "https://images.unsplash.com/photo-1589057132647-9ab52b9c8762?auto=format&fit=crop&w=600&q=80";
      default:
        return "https://images.unsplash.com/photo-1606166939213-2570466214c8?auto=format&fit=crop&w=600&q=80";
    }
  };

  return (
    <HolographicPanel 
      className={`rounded-xl overflow-hidden ${
        isRankLocked ? "opacity-50 hover:opacity-100 transition-opacity" : ""
      }`}
    >
      <div className="h-40 bg-muted relative">
        {!isRankLocked ? (
          <div 
            className="w-full h-full bg-cover bg-center"
            style={{ backgroundImage: `url(${getImageUrl(reward.image)})` }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-background">
            <span className="text-5xl text-muted">🔒</span>
          </div>
        )}
        <div className="absolute top-2 right-2 bg-accent text-black text-xs font-bold px-2 py-1 rounded-full">
          {reward.pointsCost} pts
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-lg font-bold mb-1">{reward.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">{reward.description}</p>
        {isRankLocked ? (
          <Button variant="secondary" disabled className="w-full cursor-not-allowed">
            Rank Locked
          </Button>
        ) : (
          <Button 
            variant="default" 
            className="w-full bg-primary/30 hover:bg-primary/50"
            disabled={!canRedeem}
            onClick={onRedeem}
          >
            {canRedeem ? "Redeem Reward" : "Not Enough Points"}
          </Button>
        )}
      </div>
    </HolographicPanel>
  );
}
