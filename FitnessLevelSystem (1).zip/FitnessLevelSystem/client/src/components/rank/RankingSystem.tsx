import React from "react";
import HolographicPanel from "@/components/ui/holographic-panel";

interface Rank {
  name: string;
  levels: string;
  current?: boolean;
}

interface RankingSystemProps {
  currentLevel: number;
  currentRank: string;
  rankProgress: number; // 0-100%
}

export function RankingSystem({ currentLevel, currentRank, rankProgress }: RankingSystemProps) {
  const ranks: Rank[] = [
    { name: "E-Rank Hunter", levels: "Levels 1-10" },
    { name: "D-Rank Hunter", levels: "Levels 11-30" },
    { name: "C-Rank Hunter", levels: "Levels 31-50" },
    { name: "B-Rank Hunter", levels: "Levels 51-70" },
    { name: "A-Rank Hunter", levels: "Levels 71-90" },
    { name: "S-Rank Hunter", levels: "Levels 91+" }
  ];
  
  // Update current rank display
  ranks.forEach(rank => {
    if (rank.name.startsWith(currentRank)) {
      rank.current = true;
      rank.levels = `Current: Level ${currentLevel}`;
    }
  });

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">Hunter Rank System</h2>
      </div>
      
      <HolographicPanel>
        <div className="flex flex-wrap justify-between">
          {ranks.map((rank, index) => (
            <div key={index} className="w-full md:w-auto mb-4 md:mb-0 flex items-center">
              <div className={`w-3 h-3 rounded-full ${
                rank.current ? "bg-secondary" : "bg-muted"
              } mr-3`}></div>
              <div className="flex flex-col">
                <span className={`${rank.current ? "text-white" : "text-muted-foreground"} text-sm`}>
                  {rank.name}
                </span>
                <span className={`text-xs ${rank.current ? "text-secondary" : "text-muted"}`}>
                  {rank.levels}
                </span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 bg-muted h-2 rounded-full relative">
          <div className="absolute inset-0 stat-progress rounded-full" style={{ width: `${rankProgress}%` }}></div>
          <div className="absolute -top-1 left-[calc(var(--progress)%)] w-4 h-4 bg-secondary rounded-full transform -translate-x-1/2 glow" 
               style={{ "--progress": rankProgress } as React.CSSProperties}></div>
          
          <div className="absolute -bottom-8 left-0 text-xs text-muted-foreground">
            E-Rank
          </div>
          <div className="absolute -bottom-8 left-[15%] text-xs text-muted-foreground">
            D-Rank
          </div>
          <div className="absolute -bottom-8 left-[40%] text-xs text-muted-foreground">
            C-Rank
          </div>
          <div className="absolute -bottom-8 left-[60%] text-xs text-muted-foreground">
            B-Rank
          </div>
          <div className="absolute -bottom-8 left-[80%] text-xs text-muted-foreground">
            A-Rank
          </div>
          <div className="absolute -bottom-8 right-0 text-xs text-muted-foreground">
            S-Rank
          </div>
        </div>
      </HolographicPanel>
    </section>
  );
}
