import React from "react";
import { Link } from "wouter";
import { AchievementCard } from "./AchievementCard";
import { useAchievements } from "@/hooks/use-achievements";

interface AchievementsSectionProps {
  compact?: boolean;
}

export function AchievementsSection({ compact = false }: AchievementsSectionProps) {
  const { achievements, isLoading } = useAchievements();
  
  const displayAchievements = compact ? achievements.slice(0, 6) : achievements;

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">
          {compact ? "Recent Achievements" : "Achievements"}
        </h2>
        {compact && (
          <Link 
            href="/achievements" 
            className="text-secondary hover:text-white transition-colors duration-300"
          >
            View All
          </Link>
        )}
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="holographic-panel h-36 rounded-xl p-4 animate-pulse">
              <div className="flex justify-center mb-2">
                <div className="rounded-full bg-muted-foreground/20 h-14 w-14"></div>
              </div>
              <div className="h-3 bg-muted-foreground/20 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-2 bg-muted-foreground/20 rounded w-full mx-auto mb-2"></div>
              <div className="h-2 bg-muted-foreground/20 rounded w-1/2 mx-auto"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {displayAchievements.map((achievement) => (
            <AchievementCard key={achievement.id} achievement={achievement} />
          ))}
        </div>
      )}
    </section>
  );
}
