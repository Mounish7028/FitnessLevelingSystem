import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  email: text("email").notNull().unique(),
  level: integer("level").notNull().default(1),
  xp: integer("xp").notNull().default(0),
  rank: text("rank").notNull().default("E"),
  points: integer("points").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  level: true,
  xp: true,
  rank: true,
  points: true,
});

// Fitness data table
export const fitnessData = pgTable("fitness_data", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull().defaultNow(),
  steps: integer("steps").notNull().default(0),
  calories: integer("calories").notNull().default(0),
  activeMins: integer("active_mins").notNull().default(0),
  avgHeartRate: integer("avg_heart_rate"),
  workoutMins: integer("workout_mins").default(0),
  workoutType: text("workout_type"),
  distance: integer("distance").default(0), // in meters
});

export const insertFitnessDataSchema = createInsertSchema(fitnessData).omit({
  id: true,
});

// Achievements table
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  xpReward: integer("xp_reward").notNull(),
  pointsReward: integer("points_reward").notNull(),
  requirement: json("requirement").notNull(), // JSON data with requirement criteria
  isUnlocked: boolean("is_unlocked").notNull().default(false),
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
});

// User achievements join table
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  achievementId: integer("achievement_id").notNull().references(() => achievements.id),
  unlockedAt: timestamp("unlocked_at").notNull().defaultNow(),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  unlockedAt: true,
});

// Quests table
export const quests = pgTable("quests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  xpReward: integer("xp_reward").notNull(),
  pointsReward: integer("points_reward").notNull(),
  requirement: json("requirement").notNull(), // JSON data with requirement criteria
  duration: integer("duration").notNull(), // in minutes
  questType: text("quest_type").notNull(), // daily, weekly, etc.
});

export const insertQuestSchema = createInsertSchema(quests).omit({
  id: true,
});

// User quests join table
export const userQuests = pgTable("user_quests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  questId: integer("quest_id").notNull().references(() => quests.id),
  progress: integer("progress").notNull().default(0),
  isCompleted: boolean("is_completed").notNull().default(false),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertUserQuestSchema = createInsertSchema(userQuests).omit({
  id: true,
  progress: true,
  isCompleted: true,
  completedAt: true,
});

// Devices table
export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  deviceType: text("device_type").notNull(),
  isConnected: boolean("is_connected").notNull().default(false),
  lastSynced: timestamp("last_synced"),
  deviceId: text("device_id").notNull().unique(),
});

export const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  lastSynced: true,
});

// Rewards table
export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  pointsCost: integer("points_cost").notNull(),
  isAvailable: boolean("is_available").notNull().default(true),
  requiredRank: text("required_rank"),
});

export const insertRewardSchema = createInsertSchema(rewards).omit({
  id: true,
});

// User rewards join table
export const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  rewardId: integer("reward_id").notNull().references(() => rewards.id),
  redeemedAt: timestamp("redeemed_at").notNull().defaultNow(),
});

export const insertUserRewardSchema = createInsertSchema(userRewards).omit({
  id: true,
  redeemedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type FitnessData = typeof fitnessData.$inferSelect;
export type InsertFitnessData = z.infer<typeof insertFitnessDataSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type Quest = typeof quests.$inferSelect;
export type InsertQuest = z.infer<typeof insertQuestSchema>;

export type UserQuest = typeof userQuests.$inferSelect;
export type InsertUserQuest = z.infer<typeof insertUserQuestSchema>;

export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type Reward = typeof rewards.$inferSelect;
export type InsertReward = z.infer<typeof insertRewardSchema>;

export type UserReward = typeof userRewards.$inferSelect;
export type InsertUserReward = z.infer<typeof insertUserRewardSchema>;

// Dungeons
export const dungeons = pgTable("dungeons", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rank: text("rank").notNull(),
  description: text("description").notNull(),
  minLevel: integer("min_level").notNull(),
  requiredStamina: integer("required_stamina").notNull(),
  timeLimit: integer("time_limit").notNull(),
  rewards: json("rewards").notNull(),
  boss: json("boss"),
  type: text("type").notNull().default("standard"),
  stepsRequired: integer("steps_required").notNull(),
  activeMinutesRequired: integer("active_minutes_required").notNull(),
  status: text("status").notNull().default("available"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at")
});

export const insertDungeonSchema = createInsertSchema(dungeons);

export const userDungeons = pgTable("user_dungeons", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  dungeonId: integer("dungeon_id").notNull().references(() => dungeons.id),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  status: text("status").notNull(),
  stepsCompleted: integer("steps_completed").notNull().default(0),
  activeMinutesCompleted: integer("active_minutes_completed").notNull().default(0),
  rewards: json("rewards")
});

export const insertUserDungeonSchema = createInsertSchema(userDungeons);

export type Dungeon = typeof dungeons.$inferSelect;
export type InsertDungeon = z.infer<typeof insertDungeonSchema>;

export type UserDungeon = typeof userDungeons.$inferSelect;
export type InsertUserDungeon = z.infer<typeof insertUserDungeonSchema>;
