-- Migration file for Solo Leveling Fitness application
-- Create tables for users, fitness data, achievements, quests, devices, rewards, and dungeons

-- Users table
CREATE TABLE IF NOT EXISTS "users" (
  "id" SERIAL PRIMARY KEY,
  "username" TEXT NOT NULL UNIQUE,
  "password" TEXT NOT NULL,
  "display_name" TEXT NOT NULL,
  "email" TEXT NOT NULL UNIQUE,
  "level" INTEGER NOT NULL DEFAULT 1,
  "xp" INTEGER NOT NULL DEFAULT 0,
  "rank" TEXT NOT NULL DEFAULT 'E',
  "points" INTEGER NOT NULL DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Fitness data table
CREATE TABLE IF NOT EXISTS "fitness_data" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "date" TIMESTAMP NOT NULL DEFAULT NOW(),
  "steps" INTEGER NOT NULL DEFAULT 0,
  "calories" INTEGER NOT NULL DEFAULT 0,
  "active_mins" INTEGER NOT NULL DEFAULT 0,
  "avg_heart_rate" INTEGER,
  "workout_mins" INTEGER DEFAULT 0,
  "workout_type" TEXT,
  "distance" INTEGER DEFAULT 0
);

-- Achievements table
CREATE TABLE IF NOT EXISTS "achievements" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "icon" TEXT NOT NULL,
  "xp_reward" INTEGER NOT NULL,
  "points_reward" INTEGER NOT NULL,
  "requirement" JSONB NOT NULL,
  "is_unlocked" BOOLEAN NOT NULL DEFAULT FALSE
);

-- User achievements join table
CREATE TABLE IF NOT EXISTS "user_achievements" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "achievement_id" INTEGER NOT NULL REFERENCES "achievements"("id"),
  "unlocked_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE("user_id", "achievement_id")
);

-- Quests table
CREATE TABLE IF NOT EXISTS "quests" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "icon" TEXT NOT NULL,
  "xp_reward" INTEGER NOT NULL,
  "points_reward" INTEGER NOT NULL,
  "requirement" JSONB NOT NULL,
  "duration" INTEGER NOT NULL,
  "quest_type" TEXT NOT NULL
);

-- User quests join table
CREATE TABLE IF NOT EXISTS "user_quests" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "quest_id" INTEGER NOT NULL REFERENCES "quests"("id"),
  "progress" INTEGER NOT NULL DEFAULT 0,
  "is_completed" BOOLEAN NOT NULL DEFAULT FALSE,
  "started_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  "completed_at" TIMESTAMP,
  "expires_at" TIMESTAMP NOT NULL
);

-- Devices table
CREATE TABLE IF NOT EXISTS "devices" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "name" TEXT NOT NULL,
  "device_type" TEXT NOT NULL,
  "is_connected" BOOLEAN NOT NULL DEFAULT FALSE,
  "last_synced" TIMESTAMP,
  "device_id" TEXT NOT NULL UNIQUE
);

-- Rewards table
CREATE TABLE IF NOT EXISTS "rewards" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "image" TEXT NOT NULL,
  "points_cost" INTEGER NOT NULL,
  "is_available" BOOLEAN NOT NULL DEFAULT TRUE,
  "required_rank" TEXT
);

-- User rewards join table
CREATE TABLE IF NOT EXISTS "user_rewards" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "reward_id" INTEGER NOT NULL REFERENCES "rewards"("id"),
  "redeemed_at" TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Dungeons table
CREATE TABLE IF NOT EXISTS "dungeons" (
  "id" SERIAL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "rank" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "min_level" INTEGER NOT NULL,
  "required_stamina" INTEGER NOT NULL,
  "time_limit" INTEGER NOT NULL,
  "rewards" JSONB NOT NULL,
  "boss" JSONB,
  "type" TEXT NOT NULL DEFAULT 'standard',
  "steps_required" INTEGER NOT NULL,
  "active_minutes_required" INTEGER NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'available',
  "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
  "expires_at" TIMESTAMP
);

-- User dungeons join table
CREATE TABLE IF NOT EXISTS "user_dungeons" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL REFERENCES "users"("id"),
  "dungeon_id" INTEGER NOT NULL REFERENCES "dungeons"("id"),
  "start_time" TIMESTAMP NOT NULL DEFAULT NOW(),
  "end_time" TIMESTAMP,
  "status" TEXT NOT NULL,
  "steps_completed" INTEGER NOT NULL DEFAULT 0,
  "active_minutes_completed" INTEGER NOT NULL DEFAULT 0,
  "rewards" JSONB
);

-- Insert sample data for demonstration

-- Sample Achievements
INSERT INTO "achievements" ("name", "description", "icon", "xp_reward", "points_reward", "requirement", "is_unlocked")
VALUES 
  ('Fire Starter', 'Burn 1,000 calories in a day', 'flame-outline', 100, 50, '{"calories": 1000}', FALSE),
  ('Step Master', '10,000 steps for 5 days straight', 'footsteps-outline', 200, 100, '{"steps": 10000, "days": 5}', FALSE),
  ('Early Bird', 'Work out before 7 AM', 'time-outline', 75, 30, '{"timeOfDay": "7:00", "workout": true}', FALSE),
  ('Marathon Runner', 'Run 26.2 miles in a month', 'walk-outline', 300, 150, '{"distance": 42195, "period": "month"}', FALSE),
  ('Strength Lord', 'Log 50 strength workouts', 'barbell-outline', 250, 125, '{"workoutType": "strength", "count": 50}', FALSE),
  ('Sleep Master', '8+ hours sleep for 7 days', 'bed-outline', 150, 75, '{"sleep": 8, "days": 7}', FALSE);

-- Sample Quests
INSERT INTO "quests" ("name", "description", "icon", "xp_reward", "points_reward", "requirement", "duration", "quest_type")
VALUES 
  ('Morning Movement', 'Take 2,000 steps before 9 AM', 'walk-outline', 150, 75, '{"steps": 2000, "timeOfDay": "before 9:00"}', 180, 'daily'),
  ('Cardio Challenge', '20 minutes at elevated heart rate', 'heart-outline', 200, 100, '{"heartRate": "elevated", "duration": 20}', 600, 'daily'),
  ('Weekly Boss', 'Complete 5 workouts this week', 'trophy-outline', 500, 250, '{"workouts": 5}', 10080, 'weekly'),
  ('Daily Steps Challenge', 'Complete 8,000 steps today', 'footsteps-outline', 180, 90, '{"steps": 8000}', 1440, 'daily'),
  ('Push-Up Master', 'Complete 20 push-ups', 'fitness-outline', 120, 60, '{"exercise": "pushups", "count": 20}', 720, 'daily'),
  ('Squat Challenge', 'Do 20 squats', 'barbell-outline', 100, 50, '{"exercise": "squats", "count": 20}', 720, 'daily'),
  ('Lunges Circuit', 'Complete 15 lunges on each leg', 'body-outline', 110, 55, '{"exercise": "lunges", "count": 15}', 720, 'daily'),
  ('Cycling Explorer', 'Complete a 5km cycling session', 'bicycle-outline', 200, 100, '{"exercise": "cycling", "distance": 5}', 1440, 'daily');

-- Sample Rewards
INSERT INTO "rewards" ("name", "description", "image", "points_cost", "is_available", "required_rank")
VALUES 
  ('Premium Protein Shake', 'Unlock access to special recovery drink', 'protein_shake.jpg', 150, TRUE, NULL),
  ('Fitness Apparel Discount', '20% off at partnered fitness store', 'fitness_apparel.jpg', 300, TRUE, NULL),
  ('Premium Water Bottle', 'Special holographic Hunter design', 'water_bottle.jpg', 200, TRUE, NULL),
  ('Resistance Bands Set', 'Professional training equipment', 'resistance_bands.jpg', 400, TRUE, 'D'),
  ('Premium Creatine Supply', 'One month supply of highest quality creatine', 'creatine.jpg', 350, TRUE, 'D'),
  ('Hunter-Grade Shoes', 'Limited edition training shoes', 'training_shoes.jpg', 800, TRUE, 'C'),
  ('Mystery S-Rank Reward', 'Unlocks at S-Rank Hunter level', 'mystery_reward.jpg', 1500, TRUE, 'S');

-- Sample Dungeons
INSERT INTO "dungeons" ("name", "rank", "description", "min_level", "required_stamina", "time_limit", "rewards", "type", "steps_required", "active_minutes_required", "status")
VALUES 
  ('Forest Gate', 'E', 'A basic dungeon gate that appeared in the nearby forest. Perfect for new hunters.', 1, 20, 60, '{"xp": 300, "points": 100}', 'standard', 2000, 15, 'available'),
  ('Underground Passage', 'E', 'A slightly more challenging dungeon located beneath the city. Watch out for traps.', 5, 35, 90, '{"xp": 500, "points": 150}', 'standard', 3500, 25, 'available'),
  ('Red Gate: Burning Fortress', 'D', 'A dangerous red gate emitting intense heat. High risk, high reward.', 15, 60, 120, '{"xp": 1200, "points": 400, "items": ["Fire Essence", "Hunter''s Charm"]}', 'red_gate', 8000, 45, 'available'),
  ('Frozen Cavern', 'C', 'A vast ice dungeon with powerful monsters. Only for experienced hunters.', 35, 85, 180, '{"xp": 2400, "points": 800}', 'standard', 12000, 60, 'available');