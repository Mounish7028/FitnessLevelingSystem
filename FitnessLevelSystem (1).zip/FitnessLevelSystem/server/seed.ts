import { db } from './db';
import { 
  users, achievements, quests, rewards, dungeons
} from '../shared/schema';

async function seedDatabase() {
  console.log('Starting database seeding...');

  try {
    // Check if achievements already exist
    const existingAchievements = await db.select().from(achievements).limit(1);
    if (existingAchievements.length > 0) {
      console.log('Achievements already exist in the database.');
    } else {

    // Insert achievements
    await db.insert(achievements).values([
      {
        name: 'Fire Starter',
        description: 'Burn 1,000 calories in a day',
        icon: 'flame-outline',
        xpReward: 100,
        pointsReward: 50,
        requirement: { calories: 1000 },
        isUnlocked: false
      },
      {
        name: 'Step Master',
        description: '10,000 steps for 5 days straight',
        icon: 'footsteps-outline',
        xpReward: 200,
        pointsReward: 100,
        requirement: { steps: 10000, days: 5 },
        isUnlocked: false
      },
      {
        name: 'Early Bird',
        description: 'Work out before 7 AM',
        icon: 'time-outline',
        xpReward: 75,
        pointsReward: 30,
        requirement: { timeOfDay: "7:00", workout: true },
        isUnlocked: false
      },
      {
        name: 'Marathon Runner',
        description: 'Run 26.2 miles in a month',
        icon: 'walk-outline',
        xpReward: 300,
        pointsReward: 150,
        requirement: { distance: 42195, period: "month" },
        isUnlocked: false
      },
      {
        name: 'Strength Lord',
        description: 'Log 50 strength workouts',
        icon: 'barbell-outline',
        xpReward: 250,
        pointsReward: 125,
        requirement: { workoutType: "strength", count: 50 },
        isUnlocked: false
      },
      {
        name: 'Sleep Master',
        description: '8+ hours sleep for 7 days',
        icon: 'bed-outline',
        xpReward: 150,
        pointsReward: 75,
        requirement: { sleep: 8, days: 7 },
        isUnlocked: false
      }
    ]);
    
    console.log('Inserted achievements');

    // Insert quests
    await db.insert(quests).values([
      {
        name: 'Morning Movement',
        description: 'Take 2,000 steps before 9 AM',
        icon: 'walk-outline',
        xpReward: 150,
        pointsReward: 75,
        requirement: { steps: 2000, timeOfDay: "before 9:00" },
        duration: 180, // 3 hours
        questType: 'daily'
      },
      {
        name: 'Cardio Challenge',
        description: '20 minutes at elevated heart rate',
        icon: 'heart-outline',
        xpReward: 200,
        pointsReward: 100,
        requirement: { heartRate: "elevated", duration: 20 },
        duration: 600, // 10 hours
        questType: 'daily'
      },
      {
        name: 'Weekly Boss',
        description: 'Complete 5 workouts this week',
        icon: 'trophy-outline',
        xpReward: 500,
        pointsReward: 250,
        requirement: { workouts: 5 },
        duration: 10080, // 7 days in minutes
        questType: 'weekly'
      },
      {
        name: 'Daily Steps Challenge',
        description: 'Complete 8,000 steps today',
        icon: 'footsteps-outline',
        xpReward: 180,
        pointsReward: 90,
        requirement: { steps: 8000 },
        duration: 1440, // 24 hours in minutes
        questType: 'daily'
      },
      {
        name: 'Push-Up Master',
        description: 'Complete 20 push-ups',
        icon: 'fitness-outline',
        xpReward: 120,
        pointsReward: 60,
        requirement: { exercise: "pushups", count: 20 },
        duration: 720, // 12 hours in minutes
        questType: 'daily'
      },
      {
        name: 'Squat Challenge',
        description: 'Do 20 squats',
        icon: 'barbell-outline',
        xpReward: 100,
        pointsReward: 50,
        requirement: { exercise: "squats", count: 20 },
        duration: 720, // 12 hours in minutes
        questType: 'daily'
      },
      {
        name: 'Lunges Circuit',
        description: 'Complete 15 lunges on each leg',
        icon: 'body-outline',
        xpReward: 110,
        pointsReward: 55,
        requirement: { exercise: "lunges", count: 15 },
        duration: 720, // 12 hours in minutes
        questType: 'daily'
      },
      {
        name: 'Cycling Explorer',
        description: 'Complete a 5km cycling session',
        icon: 'bicycle-outline',
        xpReward: 200,
        pointsReward: 100,
        requirement: { exercise: "cycling", distance: 5 },
        duration: 1440, // 24 hours in minutes
        questType: 'daily'
      }
    ]);
    
    console.log('Inserted quests');

    // Insert rewards
    await db.insert(rewards).values([
      {
        name: 'Premium Protein Shake',
        description: 'Unlock access to special recovery drink',
        image: 'protein_shake.jpg',
        pointsCost: 150,
        isAvailable: true,
        requiredRank: null
      },
      {
        name: 'Fitness Apparel Discount',
        description: '20% off at partnered fitness store',
        image: 'fitness_apparel.jpg',
        pointsCost: 300,
        isAvailable: true,
        requiredRank: null
      },
      {
        name: 'Premium Water Bottle',
        description: 'Special holographic Hunter design',
        image: 'water_bottle.jpg',
        pointsCost: 200,
        isAvailable: true,
        requiredRank: null
      },
      {
        name: 'Resistance Bands Set',
        description: 'Professional training equipment',
        image: 'resistance_bands.jpg',
        pointsCost: 400,
        isAvailable: true,
        requiredRank: 'D'
      },
      {
        name: 'Premium Creatine Supply',
        description: 'One month supply of highest quality creatine',
        image: 'creatine.jpg',
        pointsCost: 350,
        isAvailable: true,
        requiredRank: 'D'
      },
      {
        name: 'Hunter-Grade Shoes',
        description: 'Limited edition training shoes',
        image: 'training_shoes.jpg',
        pointsCost: 800,
        isAvailable: true,
        requiredRank: 'C'
      },
      {
        name: 'Mystery S-Rank Reward',
        description: 'Unlocks at S-Rank Hunter level',
        image: 'mystery_reward.jpg',
        pointsCost: 1500,
        isAvailable: true,
        requiredRank: 'S'
      }
    ]);
    
    console.log('Inserted rewards');

    // Insert dungeons
    await db.insert(dungeons).values([
      {
        name: 'Forest Gate',
        rank: 'E',
        description: 'A basic dungeon gate that appeared in the nearby forest. Perfect for new hunters.',
        minLevel: 1,
        requiredStamina: 20,
        timeLimit: 60, // 60 minutes
        rewards: { xp: 300, points: 100 },
        type: 'standard',
        stepsRequired: 2000,
        activeMinutesRequired: 15,
        status: 'available',
        createdAt: new Date(),
        expiresAt: null,
        boss: null
      },
      {
        name: 'Underground Passage',
        rank: 'E',
        description: 'A slightly more challenging dungeon located beneath the city. Watch out for traps.',
        minLevel: 5,
        requiredStamina: 35,
        timeLimit: 90, // 90 minutes
        rewards: { xp: 500, points: 150 },
        type: 'standard',
        stepsRequired: 3500,
        activeMinutesRequired: 25,
        status: 'available',
        createdAt: new Date(),
        expiresAt: null,
        boss: null
      },
      {
        name: 'Red Gate: Burning Fortress',
        rank: 'D',
        description: 'A dangerous red gate emitting intense heat. High risk, high reward.',
        minLevel: 15,
        requiredStamina: 60,
        timeLimit: 120, // 120 minutes
        rewards: { xp: 1200, points: 400, items: ["Fire Essence", "Hunter's Charm"] },
        boss: { name: "Flame Sentinel", difficulty: 5 },
        type: 'red_gate',
        stepsRequired: 8000,
        activeMinutesRequired: 45,
        status: 'available',
        createdAt: new Date(),
        expiresAt: null
      },
      {
        name: 'Frozen Cavern',
        rank: 'C',
        description: 'A vast ice dungeon with powerful monsters. Only for experienced hunters.',
        minLevel: 35,
        requiredStamina: 85,
        timeLimit: 180, // 180 minutes
        rewards: { xp: 2400, points: 800 },
        type: 'standard',
        stepsRequired: 12000,
        activeMinutesRequired: 60,
        status: 'available',
        createdAt: new Date(),
        expiresAt: null,
        boss: null
      }
    ]);
    
    console.log('Inserted dungeons');

    console.log('Database seeding completed successfully');
    }
  } catch (error) {
    console.error('Database seeding failed:', error);
  }
}

// Run the seed function
seedDatabase().catch(console.error);