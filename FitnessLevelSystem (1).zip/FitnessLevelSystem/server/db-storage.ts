import { 
  users, type User, type InsertUser,
  fitnessData, type FitnessData, type InsertFitnessData,
  achievements, type Achievement, type InsertAchievement,
  userAchievements, type UserAchievement, type InsertUserAchievement,
  quests, type Quest, type InsertQuest,
  userQuests, type UserQuest, type InsertUserQuest,
  devices, type Device, type InsertDevice,
  rewards, type Reward, type InsertReward,
  userRewards, type UserReward, type InsertUserReward,
  dungeons, type Dungeon, type InsertDungeon,
  userDungeons, type UserDungeon, type InsertUserDungeon
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, sql } from "drizzle-orm";
import { IStorage } from "./storage";

/**
 * PostgreSQL implementation of the storage interface
 */
export class DbStorage implements IStorage {
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    
    // Create initial fitness data for the user
    await this.createFitnessData({
      userId: newUser.id,
      date: new Date(),
      steps: 0,
      calories: 0,
      activeMins: 0,
      workoutMins: 0,
      distance: 0
    });
    
    return newUser;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  // Fitness data methods
  async getFitnessData(userId: number, date?: Date): Promise<FitnessData | undefined> {
    if (date) {
      // Convert date to start and end of day
      const startDate = new Date(date);
      startDate.setHours(0, 0, 0, 0);
      
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      
      const [data] = await db
        .select()
        .from(fitnessData)
        .where(
          and(
            eq(fitnessData.userId, userId),
            gte(fitnessData.date, startDate),
            lte(fitnessData.date, endDate)
          )
        );
      
      return data;
    } else {
      // Get most recent fitness data
      const [data] = await db
        .select()
        .from(fitnessData)
        .where(eq(fitnessData.userId, userId))
        .orderBy(desc(fitnessData.date))
        .limit(1);
      
      return data;
    }
  }

  async getFitnessDataByDateRange(userId: number, startDate: Date, endDate: Date): Promise<FitnessData[]> {
    return db
      .select()
      .from(fitnessData)
      .where(
        and(
          eq(fitnessData.userId, userId),
          gte(fitnessData.date, startDate),
          lte(fitnessData.date, endDate)
        )
      )
      .orderBy(fitnessData.date);
  }

  async createFitnessData(data: InsertFitnessData): Promise<FitnessData> {
    const [newData] = await db
      .insert(fitnessData)
      .values(data)
      .returning();
    
    return newData;
  }

  async updateFitnessData(id: number, updates: Partial<FitnessData>): Promise<FitnessData | undefined> {
    const [updatedData] = await db
      .update(fitnessData)
      .set(updates)
      .where(eq(fitnessData.id, id))
      .returning();
    
    return updatedData;
  }

  // Achievement methods
  async getAchievements(): Promise<Achievement[]> {
    return db.select().from(achievements);
  }

  async getUserAchievements(userId: number): Promise<(Achievement & { unlockedAt?: Date })[]> {
    const userAchievementsList = await db
      .select({
        ...achievements,
        unlockedAt: userAchievements.unlockedAt
      })
      .from(achievements)
      .leftJoin(
        userAchievements,
        and(
          eq(achievements.id, userAchievements.achievementId),
          eq(userAchievements.userId, userId)
        )
      );
    
    return userAchievementsList;
  }

  async unlockAchievement(userId: number, achievementId: number): Promise<UserAchievement> {
    const [userAchievement] = await db
      .insert(userAchievements)
      .values({
        userId,
        achievementId
      })
      .returning();
    
    return userAchievement;
  }

  // Quest methods
  async getQuests(): Promise<Quest[]> {
    return db.select().from(quests);
  }

  async getUserQuests(userId: number): Promise<(UserQuest & Quest)[]> {
    const userQuestsList = await db
      .select({
        ...userQuests,
        name: quests.name,
        description: quests.description,
        icon: quests.icon,
        xpReward: quests.xpReward,
        pointsReward: quests.pointsReward,
        requirement: quests.requirement,
        duration: quests.duration,
        questType: quests.questType
      })
      .from(userQuests)
      .innerJoin(quests, eq(userQuests.questId, quests.id))
      .where(eq(userQuests.userId, userId));
    
    // Transform the result to match the expected structure
    return userQuestsList.map(record => ({
      id: record.id,
      userId: record.userId,
      questId: record.questId,
      progress: record.progress,
      isCompleted: record.isCompleted,
      startedAt: record.startedAt,
      completedAt: record.completedAt,
      expiresAt: record.expiresAt,
      name: record.name,
      description: record.description,
      icon: record.icon,
      xpReward: record.xpReward,
      pointsReward: record.pointsReward,
      requirement: record.requirement,
      duration: record.duration,
      questType: record.questType
    }));
  }

  async assignQuestToUser(userQuest: InsertUserQuest): Promise<UserQuest> {
    const [newUserQuest] = await db
      .insert(userQuests)
      .values({
        ...userQuest,
        progress: 0,
        isCompleted: false
      })
      .returning();
    
    return newUserQuest;
  }

  async updateUserQuest(id: number, updates: Partial<UserQuest>): Promise<UserQuest | undefined> {
    // First, check if this update is marking a quest as complete
    let questCompleted = false;
    if (updates.isCompleted) {
      const [currentQuest] = await db
        .select()
        .from(userQuests)
        .where(eq(userQuests.id, id));
      
      if (currentQuest && !currentQuest.isCompleted) {
        questCompleted = true;
      }
    }
    
    // Update the quest
    const [updatedQuest] = await db
      .update(userQuests)
      .set(updates)
      .where(eq(userQuests.id, id))
      .returning();
    
    if (!updatedQuest) return undefined;
    
    // If the quest was completed, add XP and points to the user
    if (questCompleted) {
      const [quest] = await db
        .select()
        .from(quests)
        .where(eq(quests.id, updatedQuest.questId));
      
      if (quest) {
        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.id, updatedQuest.userId));
        
        if (user) {
          await db
            .update(users)
            .set({
              xp: user.xp + quest.xpReward,
              points: user.points + quest.pointsReward
            })
            .where(eq(users.id, user.id));
        }
      }
    }
    
    return updatedQuest;
  }

  // Device methods
  async getUserDevices(userId: number): Promise<Device[]> {
    return db
      .select()
      .from(devices)
      .where(eq(devices.userId, userId));
  }

  async addDevice(device: InsertDevice): Promise<Device> {
    const [newDevice] = await db
      .insert(devices)
      .values(device)
      .returning();
    
    return newDevice;
  }

  async updateDevice(id: number, updates: Partial<Device>): Promise<Device | undefined> {
    const [updatedDevice] = await db
      .update(devices)
      .set(updates)
      .where(eq(devices.id, id))
      .returning();
    
    return updatedDevice;
  }

  async deleteDevice(id: number): Promise<boolean> {
    const result = await db
      .delete(devices)
      .where(eq(devices.id, id));
    
    return result.rowCount > 0;
  }

  // Reward methods
  async getRewards(): Promise<Reward[]> {
    return db.select().from(rewards);
  }

  async getUserRewards(userId: number): Promise<(Reward & { redeemedAt: Date })[]> {
    const userRewardsList = await db
      .select({
        ...rewards,
        redeemedAt: userRewards.redeemedAt
      })
      .from(userRewards)
      .innerJoin(rewards, eq(userRewards.rewardId, rewards.id))
      .where(eq(userRewards.userId, userId));
    
    // Transform the result to match the expected structure
    return userRewardsList.map(record => ({
      id: record.id,
      name: record.name,
      description: record.description,
      image: record.image,
      pointsCost: record.pointsCost,
      isAvailable: record.isAvailable,
      requiredRank: record.requiredRank,
      redeemedAt: record.redeemedAt
    }));
  }

  async redeemReward(userId: number, rewardId: number): Promise<UserReward> {
    const [userReward] = await db
      .insert(userRewards)
      .values({
        userId,
        rewardId
      })
      .returning();
    
    // Update user points
    const [reward] = await db
      .select()
      .from(rewards)
      .where(eq(rewards.id, rewardId));
    
    if (reward) {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId));
      
      if (user) {
        await db
          .update(users)
          .set({
            points: user.points - reward.pointsCost
          })
          .where(eq(users.id, userId));
      }
    }
    
    return userReward;
  }

  // Dungeon methods
  async getDungeons(): Promise<Dungeon[]> {
    return db.select().from(dungeons);
  }

  async getDungeonById(id: number): Promise<Dungeon | undefined> {
    const [dungeon] = await db
      .select()
      .from(dungeons)
      .where(eq(dungeons.id, id));
    
    return dungeon;
  }

  async getDungeonsByRank(rank: string): Promise<Dungeon[]> {
    return db
      .select()
      .from(dungeons)
      .where(eq(dungeons.rank, rank));
  }

  async createDungeon(dungeon: InsertDungeon): Promise<Dungeon> {
    const [newDungeon] = await db
      .insert(dungeons)
      .values(dungeon)
      .returning();
    
    return newDungeon;
  }

  async updateDungeon(id: number, updates: Partial<Dungeon>): Promise<Dungeon | undefined> {
    const [updatedDungeon] = await db
      .update(dungeons)
      .set(updates)
      .where(eq(dungeons.id, id))
      .returning();
    
    return updatedDungeon;
  }

  async getUserDungeons(userId: number): Promise<(UserDungeon & { dungeon: Dungeon })[]> {
    const userDungeonsList = await db
      .select({
        userDungeon: userDungeons,
        dungeon: dungeons
      })
      .from(userDungeons)
      .innerJoin(dungeons, eq(userDungeons.dungeonId, dungeons.id))
      .where(eq(userDungeons.userId, userId));
    
    // Transform the result to match the expected structure
    return userDungeonsList.map(record => ({
      ...record.userDungeon,
      dungeon: record.dungeon
    }));
  }

  async startDungeon(userId: number, dungeonId: number): Promise<UserDungeon> {
    const [dungeon] = await db
      .select()
      .from(dungeons)
      .where(eq(dungeons.id, dungeonId));
    
    if (!dungeon) {
      throw new Error(`Dungeon with id ${dungeonId} not found`);
    }
    
    const [userDungeon] = await db
      .insert(userDungeons)
      .values({
        userId,
        dungeonId,
        status: 'in_progress',
        stepsCompleted: 0,
        activeMinutesCompleted: 0
      })
      .returning();
    
    return userDungeon;
  }

  async updateUserDungeon(id: number, updates: Partial<UserDungeon>): Promise<UserDungeon | undefined> {
    const [updatedUserDungeon] = await db
      .update(userDungeons)
      .set(updates)
      .where(eq(userDungeons.id, id))
      .returning();
    
    return updatedUserDungeon;
  }

  async completeDungeon(userId: number, dungeonId: number, rewards: any): Promise<UserDungeon | undefined> {
    // Find the user dungeon
    const [userDungeon] = await db
      .select()
      .from(userDungeons)
      .where(
        and(
          eq(userDungeons.userId, userId),
          eq(userDungeons.dungeonId, dungeonId),
          eq(userDungeons.status, 'in_progress')
        )
      );
    
    if (!userDungeon) {
      return undefined;
    }
    
    // Update user dungeon
    const [updatedUserDungeon] = await db
      .update(userDungeons)
      .set({
        status: 'completed',
        endTime: new Date(),
        rewards
      })
      .where(eq(userDungeons.id, userDungeon.id))
      .returning();
    
    // Get dungeon information for rewards
    const [dungeon] = await db
      .select()
      .from(dungeons)
      .where(eq(dungeons.id, dungeonId));
    
    if (dungeon && updatedUserDungeon) {
      // Update user with rewards
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, userId));
      
      if (user) {
        const dungeonRewards = typeof dungeon.rewards === 'string' 
          ? JSON.parse(dungeon.rewards)
          : dungeon.rewards;
        
        await db
          .update(users)
          .set({
            xp: user.xp + (dungeonRewards.xp || 0),
            points: user.points + (dungeonRewards.points || 0)
          })
          .where(eq(users.id, userId));
      }
    }
    
    return updatedUserDungeon;
  }

  // Leaderboard methods
  async getLeaderboard(): Promise<(User & { steps: number })[]> {
    // Using a raw query to get total steps for each user
    const leaderboard = await db.execute<
      (User & { steps: number })[]
    >(sql`
      SELECT 
        u.*, 
        COALESCE(SUM(fd.steps), 0) as steps
      FROM users u
      LEFT JOIN fitness_data fd ON u.id = fd.user_id
      GROUP BY u.id
      ORDER BY steps DESC
      LIMIT 10
    `);
    
    return leaderboard;
  }
}

export const dbStorage = new DbStorage();